# TANI.io - Agricultural Data Analysis Platform

TANI.io adalah platform analisis data pertanian yang menyediakan visualisasi dan analisis data panen padi di Indonesia. Platform ini terdiri dari frontend Next.js dan beberapa API backend untuk mengolah data pertanian.

## 🚀 Fitur

- **Dashboard Interaktif**: Visualisasi data panen padi dalam berbagai format chart
- **Chatbot AI**: Asisten AI untuk analisis data pertanian menggunakan Gemini AI
- **Data Real-time**: Integrasi dengan database PostgreSQL untuk data terkini
- **Responsive Design**: Antarmuka yang responsif untuk berbagai perangkat
- **REST API**: API lengkap untuk mengakses data pertanian

## 🛠️ Teknologi

### Frontend

- **Next.js 15**: React framework untuk production
- **TypeScript**: Type-safe JavaScript
- **Tailwind CSS**: Utility-first CSS framework
- **Chart.js**: Library untuk visualisasi data
- **React Markdown**: Render markdown content

### Backend

- **FastAPI**: Modern Python web framework
- **PostgreSQL**: Database relational
- **SQLAlchemy**: Python SQL toolkit dan ORM
- **LangChain**: Framework untuk aplikasi AI
- **Gemini AI**: Google's generative AI model

### DevOps

- **Docker**: Containerization
- **Docker Compose**: Multi-container orchestration

## 📂 Struktur Proyek

```
tani-ai/
├── app/                    # Next.js app directory
├── components/             # React components
├── lib/                    # Utility libraries
├── public/                 # Static assets
├── types/                  # TypeScript type definitions
├── ApiChatbot/             # Chatbot API service
├── ApiTool/                # Data analysis API service
├── ApiDB/                  # Database configuration
├── docker-compose.yml      # Docker compose configuration
└── README.md
```

## 🚀 Cara Menjalankan

### Prerequisites

- Node.js 18+ dan npm
- Python 3.9+
- PostgreSQL 16
- Docker & Docker Compose (opsional tapi direkomendasikan)

### 🔧 Development Environment

#### Menjalankan dengan Docker (Recommended)

1. **Clone repository**

   ```bash
   git clone <repository-url>
   cd tani-ai
   ```

2. **Setup environment**

   ```bash
   cp .env.example .env
   # Edit .env sesuai kebutuhan
   ```

3. **Jalankan semua services**

   ```bash
   docker-compose up -d --build
   ```

4. **Akses aplikasi**
   - Frontend: http://localhost:8013
   - Chatbot API: http://localhost:8012
   - Tool API: http://localhost:8011
   - PgAdmin: http://localhost:8080

#### Menjalankan Manual

1. **Setup Database**

   ```bash
   # Windows
   setup_database.bat

   # Linux/Mac
   ./setup_database.sh
   ```

2. **Setup Backend APIs**

   ```bash
   # Tool API
   cd ApiTool
   pip install -r requirements.txt
   python start_api.py

   # Chatbot API
   cd ../ApiChatbot
   pip install -r requirements.txt
   python start_api.py
   ```

3. **Setup Frontend**
   ```bash
   npm install
   npm run dev
   ```

### 🌐 Production Deployment (VPS)

#### Quick Deploy ke VPS

1. **Upload project ke VPS**

   ```bash
   # Upload semua files ke VPS 10.11.1.207
   scp -r tani-ai/ user@10.11.1.207:/path/to/deployment/
   ```

2. **Jalankan deployment script**

   ```bash
   # Linux/Mac
   chmod +x deploy-vps.sh
   ./deploy-vps.sh

   # Windows (pada VPS)
   deploy-vps.bat
   ```

3. **Akses aplikasi**
   - Frontend: http://10.11.1.207:8013
   - Chatbot API: http://10.11.1.207:8012
   - Tool API: http://10.11.1.207:8011
   - PgAdmin: http://10.11.1.207:8080

#### Manual VPS Setup

1. **Setup environment production**

   ```bash
   cp .env.production .env
   ```

2. **Deploy dengan Docker Compose**

   ```bash
   docker-compose -f docker-compose.production.yml up -d --build
   ```

3. **Verifikasi deployment**
   ```bash
   docker-compose -f docker-compose.production.yml ps
   ```

#### VPS Management Commands

Gunakan script `manage-vps.sh` untuk mengelola aplikasi di VPS:

```bash
# Lihat status services
./manage-vps.sh status

# Start/Stop/Restart services
./manage-vps.sh start
./manage-vps.sh stop
./manage-vps.sh restart

# Lihat logs
./manage-vps.sh logs           # Semua logs
./manage-vps.sh logs-api       # API logs only
./manage-vps.sh logs-front     # Frontend logs only

# Health check
./manage-vps.sh health

# Backup database
./manage-vps.sh backup

# Update services
./manage-vps.sh update

# Monitor real-time
./manage-vps.sh monitor

# Cleanup Docker
./manage-vps.sh cleanup
```

#### 🔧 Database Connection Fix

Jika mengalami error database connection seperti:

```
connection to server at "localhost" (::1), port 5432 failed: Connection refused
```

Jalankan script fix otomatis:

```bash
./fix-database.sh
```

Atau perbaiki manual dengan memastikan `DATABASE_URL` di `.env.production` menggunakan nama container:

```bash
DATABASE_URL=postgresql://dev:tani@database:5432/tani_db
```

**(Gunakan `database` bukan `localhost`)**

## 🔧 Development

### Frontend Development

```bash
npm install
npm run dev
```

### API Development

```bash
# ApiChatbot
cd ApiChatbot
pip install -r requirements.txt
uvicorn api_endpoints:app --reload --port 8012

# ApiTool
cd ApiTool
pip install -r requirements.txt
uvicorn api_endpoints:app --reload --port 8011
```

## 📊 API Endpoints

### Data Analysis API (Port 8011)

- `GET /api/data/nasional` - Data nasional
- `POST /api/data/panen` - Data panen per wilayah
- `GET /api/charts/climate` - Data chart cuaca
- `GET /api/charts/harvest-regions` - Chart wilayah panen
- `GET /api/charts/machinery-effectiveness` - Chart efektivitas alsintan

### Chatbot API (Port 8012)

- `POST /api/chat` - Chat dengan AI assistant
- `GET /health` - Health check

## 🐳 Docker Services

| Service     | Port | Description              |
| ----------- | ---- | ------------------------ |
| frontend    | 8013 | Next.js frontend         |
| chatbot-api | 8012 | AI chatbot service       |
| tool-api    | 8011 | Data analysis API        |
| database    | 5432 | PostgreSQL database      |
| pgadmin     | 8080 | Database admin interface |

## 🔐 Environment Variables

### Frontend (.env)

```env
NEXT_PUBLIC_API_TOOL_URL=http://localhost:8011
NEXT_PUBLIC_API_CHATBOT_URL=http://localhost:8012
```

### Backend APIs

```env
DATABASE_URL=postgresql://dev:tani@database:5432/tani_db
GOOGLE_API_KEY=your-gemini-api-key
API_TOOL_URL=http://tool-api:8011
```

## 🧪 Testing

```bash
# Test API endpoints
curl http://localhost:8011/health
curl http://localhost:8012/health

# Test frontend
curl http://localhost:8013
```

## 📝 License

This project is licensed under the MIT License.

## 👥 Contributors

- **Reswandana** - _Project Lead & Development_

## 🤝 Contributing

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📞 Contact

Project Link: [https://github.com/reswandana00/TANI.io---Internship-Project](https://github.com/reswandana00/TANI.io---Internship-Project)
#   T A N I . i o - - - I n t e r n s h i p - P r o j e c t 
 
 
